package javafxapplication1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.Event;



public class ConnController implements Initializable {
    @FXML private ImageView imgLogo ;
    @FXML private TextField username;
    @FXML private PasswordField password;
    @FXML private Button login;
    @FXML private Label loginMessage;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Image img = new Image("Images/libon.gif");
        imgLogo.setImage(img);
    } 
    
    public void login(MouseEvent event) throws IOException{
        if (username.getText().isBlank()== false && password.getText().isBlank() == false){
            validate();
        }else{
        loginMessage.setText("Please enter username and password");
        }
    }
    
    public void validate() throws IOException{
        DBinteract.connect();
        String sql = "select count(*) from stud where user= '"+ username.getText() +"' and passw ='"+ password.getText()+"'";
        
        try {
          ResultSet rs= DBinteract.select(sql);
          while(rs.next()){
             if(rs.getInt(1)== 1){
                 Stage stage = new Stage();
                 Parent root = FXMLLoader.load(getClass().getResource("library.fxml"));
                 Scene scene = new Scene(root);
                 stage.setScene(scene);
                 stage.show();    
             }else{
                 loginMessage.setText("Invalid username or password. Try again");
             }
            }
        } catch (SQLException e) {
	  e.printStackTrace();
	}
    }
}
   
